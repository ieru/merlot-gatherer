/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package merlotcrawler;

/**
 *
 * @author Victor
 */
public class Pruebas {
    public static void main(String[] args)
    {
        //try{
            //ViewMaterial material = new ViewMaterial(725822);
        //}catch(Exception e)
        //{
            //System.out.println(e.getMessage());
        //}
        //ViewMember member = new ViewMember(32436);
        //System.out.println(member.hasPersonalCollections());
        //Portfolios portfolios = new Portfolios(32436);
        ViewMaterial material = new ViewMaterial(630348);
        //System.out.println(material.getAuthorID());

    }

}
